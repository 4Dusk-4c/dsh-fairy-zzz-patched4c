/** Host half of the companion patch; all fixes live in the Client module. */
export function apply() {}
