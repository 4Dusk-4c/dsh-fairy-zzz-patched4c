window.__ModuleLoader__.load({
  id: 'dsh-fairy-zzz-patched4c',
  factory() {
    const PATCH_ID = 'dsh-fairy-zzz-patched4c'
    const SPEED_KEY = 'fairy.zzz.patched.boot-speed'
    const SPEEDS = [1, 1.5, 2, 3]

    const CSS = `
/* ——— 标题栏沉浸：只改桌面壳 preload 的隐藏探针，侧栏底色不受影响 ——— */
body > span[style*="--dsw-specific-sidebar-fill"]{background-color:rgba(1,9,17,0)!important}

/* ——— 眼徽恢复正圆：DSH 主题对 * 设置了 corner-shape:superellipse(1.5) ——— */
.fz3-eye-halo,.fz3-eye-ring,.fz3-eye-scan,.fz3-eye-flash{corner-shape:round!important}

/* ——— 字标：鸿蒙黑体 ——— */
.fz3-sb-text b,.fz3-brandname,.fz3-brandname b{
  font-family:"HarmonyOS Sans SC","HarmonyOS Sans","HarmonyOS_Sans_SC","鸿蒙黑体","Microsoft YaHei UI","PingFang SC","Noto Sans SC",system-ui,sans-serif!important;
  font-style:normal!important;
}

/* ——— 开机控制条：纯文字、无底色，和问好页 SKIP 一致 ——— */
.fz3p-boot-ctl{
  position:absolute;right:clamp(12px,2.4vw,30px);bottom:clamp(10px,2.6vh,26px);z-index:6;
  display:flex;align-items:center;gap:22px;pointer-events:auto;
}
.fz3p-boot-speed{display:flex;align-items:center;gap:2px}
.fz3p-boot-speed button{
  font:inherit;font-size:10px;letter-spacing:.18em;color:rgba(150,200,235,.55);
  background:none;border:0;padding:8px 5px;cursor:pointer;line-height:1;
}
.fz3p-boot-speed button:hover{color:#9fefff}
.fz3p-boot-speed button[data-on="1"]{color:#eaf7ff;text-shadow:0 0 12px rgba(87,232,255,.6);box-shadow:inset 0 -1px 0 rgba(159,239,255,.55)}
.fz3p-boot-skip{
  font:inherit;font-size:9.5px;letter-spacing:.26em;color:rgba(150,200,235,.55);
  background:none;border:0;padding:8px;cursor:pointer;
}
.fz3p-boot-skip:hover{color:#9fefff}
@media (max-width:620px){.fz3p-boot-ctl{gap:10px}}
`

    function readSpeed() {
      try {
        const value = Number(localStorage.getItem(SPEED_KEY))
        return SPEEDS.includes(value) ? value : 1
      } catch {
        return 1
      }
    }

    function saveSpeed(value) {
      try {
        localStorage.setItem(SPEED_KEY, String(value))
      } catch {}
    }

    function walkText(root, visit) {
      if (!root) return
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
      let node = walker.nextNode()
      while (node) {
        visit(node)
        node = walker.nextNode()
      }
    }

    /* 在原版开机段上叠加倍速和 SKIP，不改原版 React 树，只追加一个兄弟节点。 */
    function injectBoot(boot) {
      if (!boot) return null
      if (boot.querySelector('.fz3p-boot-ctl')) return null
      if (boot.querySelector('.fz3-boot-ctl')) return null /* 原版已经带控制条时不重复注入 */
      const video = Array.from(boot.children).find((child) => child.tagName === 'VIDEO')
      if (!video) return null /* 视频还没挂上，下一次 sync 再试 */

      let speed = readSpeed()
      const ctl = document.createElement('div')
      ctl.className = 'fz3p-boot-ctl'

      const group = document.createElement('span')
      group.className = 'fz3p-boot-speed'
      const buttons = SPEEDS.map((value) => {
        const button = document.createElement('button')
        button.type = 'button'
        button.dataset.speed = String(value)
        button.textContent = value + '×'
        button.setAttribute('aria-label', value + ' 倍速')
        group.appendChild(button)
        return button
      })

      function markSpeed() {
        for (const button of buttons) {
          const on = Number(button.dataset.speed) === speed
          button.dataset.on = on ? '1' : '0'
          button.setAttribute('aria-pressed', String(on))
        }
      }

      function applySpeed(value, persist) {
        speed = value
        try {
          video.playbackRate = value
        } catch {}
        markSpeed()
        if (persist) saveSpeed(value)
      }

      for (const button of buttons) {
        button.addEventListener('click', () => applySpeed(Number(button.dataset.speed), true))
      }

      const skip = document.createElement('button')
      skip.type = 'button'
      skip.className = 'fz3p-boot-skip'
      skip.textContent = 'SKIP ▸'
      skip.setAttribute('aria-label', '跳过开机动画')
      ctl.append(group, skip)
      boot.appendChild(ctl)

      const onPlay = () => {
        try {
          video.playbackRate = speed
        } catch {}
      }
      video.addEventListener('play', onPlay)
      video.addEventListener('loadedmetadata', onPlay)
      applySpeed(speed, false)

      skip.addEventListener('click', () => {
        try {
          video.pause()
        } catch {}
        const hidden = boot.querySelector('button.fz3-skip') || boot.querySelector('.fz3-boot-foot button')
        if (hidden) {
          try {
            hidden.click()
            return
          } catch {}
        }
        try {
          video.dispatchEvent(new Event('ended', { bubbles: true }))
        } catch {}
      })

      return () => {
        video.removeEventListener('play', onPlay)
        video.removeEventListener('loadedmetadata', onPlay)
        ctl.remove()
      }
    }

    function apply(ctx) {
      if (typeof document === 'undefined' || !document.head || !document.body) return
      const cleanups = []

      const oldStyle = document.querySelector('style[data-plugin="' + PATCH_ID + '"]')
      if (oldStyle) oldStyle.remove()
      const style = document.createElement('style')
      style.dataset.plugin = PATCH_ID
      style.textContent = CSS
      document.head.appendChild(style)
      cleanups.push(() => style.remove())

      /* 原生消息尾部「用量」→「电费」；气泡标题同步。React 重渲染后由低频定时器补回。 */
      const rewriteText = () => {
        for (const box of document.querySelectorAll('[class*="_endInfo"]')) {
          walkText(box, (node) => {
            const value = node.nodeValue || ''
            if (/^\s*用量/.test(value)) node.nodeValue = value.replace(/^(\s*)用量/, '$1电费')
          })
        }
        for (const head of document.querySelectorAll('.fz3-bubble-head')) {
          const value = (head.textContent || '').replace(/\s+/g, ' ').trim()
          if (value === 'Fairy · 用量') head.textContent = 'Fairy · 电费'
          else if (value === 'Fairy · 本轮结算') head.textContent = 'Fairy · 本轮电费'
        }
      }
      rewriteText()
      const textTimer = setInterval(() => {
        try {
          rewriteText()
        } catch {}
      }, 800)
      cleanups.push(() => clearInterval(textTimer))

      /* 监听原版开机段出现/卸载；注入控制条，卸载时一并收回。 */
      let currentBoot = null
      let bootCleanup = null
      let bootPending = 0
      const syncBoot = () => {
        const boot = document.querySelector('.fz3-boot')
        const changed = boot !== currentBoot
        if (changed) {
          if (bootCleanup) {
            try {
              bootCleanup()
            } catch {}
            bootCleanup = null
          }
          currentBoot = boot
        }
        if (!boot) return
        if (boot.querySelector('.fz3p-boot-ctl') || boot.querySelector('.fz3-boot-ctl')) return
        if (bootCleanup) {
          try {
            bootCleanup()
          } catch {}
          bootCleanup = null
        }
        bootCleanup = injectBoot(boot)
      }
      const observer = new MutationObserver(() => {
        if (bootPending) return
        bootPending = setTimeout(() => {
          bootPending = 0
          syncBoot()
        }, 120)
      })
      observer.observe(document.body, { childList: true, subtree: true })
      const bootTimer = setInterval(syncBoot, 800)
      syncBoot()
      cleanups.push(() => {
        observer.disconnect()
        clearInterval(bootTimer)
        if (bootPending) clearTimeout(bootPending)
        if (bootCleanup) {
          try {
            bootCleanup()
          } catch {}
          bootCleanup = null
        }
      })

      const cleanup = () => {
        while (cleanups.length > 0) {
          const fn = cleanups.pop()
          try {
            fn()
          } catch {}
        }
      }
      if (ctx && typeof ctx.effect === 'function') ctx.effect(() => cleanup)
      else window.addEventListener('pagehide', cleanup, { once: true })
    }

    return { apply }
  },
})
